# PoolTogether - Brand Assets
Logos and colours for PoolTogether.

## Usage

We would like you to use any of the the assets 'as is'. If you need a modified version of any of the logos feel free to <a href='mailto:hello@pooltogether.us'>reach out to us</a> and we'll be happy to help.

Please do not use any of the PoolTogether assets as the logo or in your logo for your app or brand. Thanks!

